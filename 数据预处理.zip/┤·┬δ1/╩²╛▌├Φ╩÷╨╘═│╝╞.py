import numpy as np
from sklearn import datasets
import pandas as pd
from collections import Counter,defaultdict
import matplotlib as mpl
import matplotlib.pyplot as plt
import missingno as msn
mpl.rcParams["font.sans-serif"] = ["SimHei"]
mpl.rcParams["axes.unicode_minus"] = False
irisdf=pd.read_excel('D:\\日常文件\\数学建模\\第一次训练赛\\养老数据2.xlsx')

#iris_datas=datasets.load_iris()
'''print(iris_datas.data)
print(iris_datas.target_name)'''
#iris=pd.DataFrame(df)
#iris=pd.DataFrame(iris_datas.data,columns=["SepalLength","SepalWidth","PetalLength","PetalWidth"])
'''iris.shape
print(iris.head())
print(iris.tail())
print(iris.describe().T)
鸢尾花数据集的可视化'''
#画图大图
'''style_list=['o','^','s']
data=iris_datas.data
labels=iris_datas.target_names
cc=defaultdict(list)

for i,d in enumerate(data):
    cc[labels[int(i/50)]].append(d)
p_list=[]
c_list=[]
for each in [0,2]:
    for i,(c,ds)in enumerate(cc.items()):
        draw_data=np.array(ds)
        p=plt.plot(draw_data[:, each],draw_data[:, each+1],style_list[i])
        p_list.append(p)
        c_list.append(c)
    plt.legend(map(lambda x:x[0],p_list),c_list)
    plt.title("Length and width of iris petal") if each else plt.title("Length and width of iris petal")
    plt.xlabel("Length of iris petal(cm)") if each else plt.xlabel(u"Length of iris sepal(cm)")
    plt.ylabel("Width of iris petal(cm)") if each else plt.ylabel(u"Width of iris sepal(cm)")
    plt.show()
'''
#直方图
#irisdf = pd.DataFrame(iris,columns=['sepal_length','sepal_width','petal_length','petal_width'])
#irisdf.hist()
#直方图+散点图
'''pd.plotting.scatter_matrix(irisdf,alpha = 0.5,
                           figsize =(10,8) ,grid = False,
                           diagonal = 'hist',marker = 'o',
                           range_padding = 0.01)'''
#plt.show()

#散点图
#irisdf.plot(x="sepal_length",y="sepal_width",kind="scatter")
#plt.show()

#箱线图
irisdf.plot(kind="box",subplots=True,layout=(3,3),sharex=False,sharey=False)
plt.show()
#空缺值可视化——缺失密度展示
msn.matrix(irisdf, labels=True)
plt.show()

#线型图
irisdf.plot(x='Year', y=['人口数量', '恩格尔系数','抚养比','居民消费水平','城乡比重']
            ,marker='o', linestyle=':',linewidth=0.8)
plt.axhline(y=0.0, c='black', lw=1)
#plt.hlines(0, xmin = 0, xmax = 10, ,color = 'black')

#直方图
irisdf.plot(x='Year', y=['人口数量', '恩格尔系数','抚养比','居民消费水平','城乡比重'],kind="scatter")
plt.show()


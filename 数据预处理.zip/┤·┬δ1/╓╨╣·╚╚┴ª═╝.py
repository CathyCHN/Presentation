from pyecharts.charts import Map, Geo
from pyecharts import options as opts
#from pyecharts import Map
import pandas as pd
import numpy as np
import math
df = pd.read_excel('D:\\日常文件\\养老数据（省份）.xlsx')
province, ratio = np.array(df['省份']), np.array(df['千人床位数'])
# 省和直辖市
province_distribution = dict(zip(province, ratio))

provice = list(province_distribution.keys())
values = list(province_distribution.values())
province=[i[:-1] for i in provice]
c_value = [int(i) for i in values]
print(type(values[0]))
_max =max(values)
_min =min(values)
map = Map()
map.render(path="中国地图.html")
#provice=list(province_distribution.items())

maptype='china' # 只显示全国直辖市和省级
mp= [z for z in zip(province, c_value)]
print(mp)
china = (
    Map()
    .add("", [z for z in zip(province, c_value)], "china",bounding_coords=[0,50]).set_global_opts(title_opts=opts.TitleOpts(title=" 各地区千人床位数"),
visualmap_opts=opts.VisualMapOpts(max_=40),))
china.render("render.html")
import random
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


# 计算欧式距离
def Distance(dataSet, centroids, k) -> np.array:
    dis = []
    for data in dataSet:
        diff = np.tile(data, (k, 1)) - centroids  # 行数上复制k份，方便作差
        temp1 = diff ** 2
        temp2 = np.sum(temp1, axis=1)  # 按行相加
        dis_temp = temp2 ** 0.5
        dis.append(dis_temp)
    dis = np.array(dis)  # 转换为一个array类型
    return dis


# 更新质心
def Update_cen(dataSet, centroids, k):
    # 计算每个样本到质心的距离，返回值是array数组
    distance = Distance(dataSet, centroids, k)
    # print("输出所有样本到质心的距离：", distance)
    # 分组并计算新的质心
    minIndex = np.argmin(distance, axis=1)  # axis=1 返回每行最小值的索引
    # print("输出最小值索引", minIndex)
    newCentroids = pd.DataFrame(dataSet).groupby(minIndex).mean()
    # print("新的质心(dataframe)：", newCentroids)
    newCentroids = newCentroids.values
    # print("新的质心(值）：", newCentroids)

    # 计算变化量
    changed = newCentroids - centroids
    return changed, newCentroids


# k-means 算法实现
def kmeans(dataSet, k):
    # (1) 随机选定k个质心
    centroids = random.sample(dataSet, k)
    print("随机选定两个质心：", centroids)

    # (2) 计算样本值到质心之间的距离，直到质心的位置不再改变
    changed, newCentroids = Update_cen(dataSet, centroids, k)
    while np.any(changed):
        changed, newCentroids = Update_cen(dataSet, newCentroids, k)
    centroids = sorted(newCentroids.tolist())

    # (3) 根据最终的质心，计算每个集群的样本
    cluster = []
    dis = Distance(dataSet, centroids, k)  # 调用欧拉距离
    minIndex = np.argmin(dis, axis=1)
    for i in range(k):
        cluster.append([])
    for i, j in enumerate(minIndex):  # enumerate()可同时遍历索引和遍历元素
        cluster[j].append(dataSet[i])

    return centroids, cluster


# 创建数据集
def createDataSet():
    df = pd.read_excel('D:\\日常文件\\数学建模\\第一次训练赛\\数据集聚类标注2.xlsx')
    province, ratio = np.array(df['60岁以上老人数']), np.array(df['养老机构床位'])
    province_distribution = dict(zip(province, ratio))
    provice = list(province_distribution.keys())
    values = list(province_distribution.values())
    province_distribution = dict(zip(province, ratio))
    data=[list(z) for z in zip(province, values)]
    return data


if __name__ == '__main__':
    dataset = createDataSet()  # type(dataset)='list'
    centroids, cluster = kmeans(dataset, 3)  # 2 代表的是分为2类=2个质心
    print('质心为：%s' % centroids)
    print('集群为：%s' % cluster)
    # x = list(np.array(dataset).T[0])
    # y = list(np.array(dataset).T[1])
    plt.scatter(list(np.array(dataset).T[0]), list(np.array(dataset).T[1]), marker='o', color='green', label="数据集" )
    plt.scatter(list(np.array(centroids).T[0]), list(np.array(centroids).T[1]), marker='x', color='red', label="质心")
    plt.show()


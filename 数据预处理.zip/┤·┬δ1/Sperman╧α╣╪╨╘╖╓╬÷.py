import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

inputdata = pd.read_excel('D:\\养老数据2.xlsx').drop(columns='Year')
plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False
df = inputdata.copy()
_, ax = plt.subplots(figsize=(12, 10))
corr = df.corr(method='pearson')  # 使用皮尔逊系数
# corr = df.corr(method='kendall')  # 肯德尔秩相关系数
#corr = df.corr(method='spearman') # 斯皮尔曼秩相关系数
cmap = sns.diverging_palette(220, 10, as_cmap=True)
_ = sns.heatmap(
    corr,
    cmap=cmap,  # 数据值到颜色空间的映射
    square=True,  # 每个单元格都是正方形
    cbar_kws={'shrink': .9},
    ax=ax,
    annot=True,
    annot_kws={'fontsize': 12})
plt.show()

import seaborn as sns
from matplotlib import pyplot as plt
import matplotlib as mpl
import pandas as pd
import numpy as np
mpl.rcParams["font.sans-serif"] = ["SimHei"]
mpl.rcParams["axes.unicode_minus"] = False
tips = pd.read_excel('D:\\日常文件\\数据集聚类标注2.xlsx')
tips.head()
sns.relplot(x="60岁以上老人数",y="养老机构床位",hue="聚类种类",data=tips)
plt.show()
